package com.sarah.zookeeper;

public class Gorilla extends Mamal{

	public Gorilla() {
		super(100);
	}
	
	
	
// Gorilla methods
	
	
	public void throwSomething() {
		energyLevel -= 5;
		System.out.println(String.format("**The Gorilla has thrown something \nHer energy is => %s%%"
				, energyLevel));
	}
	
	public void eatBananas() {
		
		System.out.println("**The Gorilla is satisfied after eating a Banana");
		energyLevel += 10;
		System.out.println(String.format("her energy now is => %s%%", energyLevel));
	}
	
	@Override
	public void displayEnergy() {
		System.out.println(String.format("the Gorilla energy level is : %d%%",this.getEnergyLevel()));
		} 
	
	public void climb() {
		System.out.println("**The Gorilla climed a tree");
		energyLevel -= 10;
		System.out.println(String.format("her energy now is => %s%%", energyLevel));
	}

}
