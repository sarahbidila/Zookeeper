package com.sarah.zookeeper;

public class TestZookeeper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gorilla gorilla = new Gorilla();
		gorilla.displayEnergy();
		
		gorilla.throwSomething();
		gorilla.eatBananas();
		gorilla.climb();
		
		}
		
	}


