package com.sarah.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat bat = new Bat();
		
		int i;
		for (i=0;i<=2;i++) {
		bat.attackTown();
		}
		System.out.println("****************************");
		int i1;
		for (i1=0;i1<=1;i1++) {
		bat.eatHuman();
		}
		System.out.println("****************************");
		int i2;
		for (i2=0;i2<=1;i2++) {
		bat.fly();
		}
		
	}

}
