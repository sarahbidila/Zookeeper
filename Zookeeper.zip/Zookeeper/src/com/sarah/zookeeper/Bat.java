package com.sarah.zookeeper;

public class Bat extends Mamal{

	public Bat() {
	super(300);	
	}
	
	
	@Override
	public void displayEnergy() {
		System.out.println(String.format("the Bat's energy level is : %d%%",this.getEnergyLevel()));
	}

	//fly method
	public void fly() {
		System.out.println(String.format("the Bat has taken off ***and his"
				+ "energy is now : %s%%",this.getEnergyLevel()-50));
		
	}
	
	//eatHuman method
		public void eatHuman() {
			System.out.println("the Bat has eaten a human being!");
			this.energyLevel +=25;
			displayEnergy();
		}
		
	//attackTown method
	public void attackTown() {
			System.out.println("A town is on fire!!");
			this.energyLevel -=100;
			displayEnergy();
		}
	
}
