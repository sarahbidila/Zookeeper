package com.sarah.zookeeper;

public class TestGorilla {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Gorilla gorilla = new Gorilla();
//throw three things
gorilla.throwSomething();
gorilla.throwSomething();
gorilla.throwSomething();
//eat banana twice
gorilla.eatBananas();
gorilla.eatBananas();
//climb once
gorilla.climb();
	}

}
