package com.sarah.zookeeper;

public abstract class Mamal {
//***member variables***
	protected Integer energyLevel=100;
	
	
	//constructor
	public Mamal(Integer energyLevel ) {
	
	this.energyLevel =energyLevel ;
}

	
	
	
	public abstract void displayEnergy();
	

	
	
	
	//getters and setters
	public Integer getEnergyLevel() {
		return energyLevel;
	}


	public void setEnergyLevel(Integer energyLevel) {
		this.energyLevel = energyLevel;
	}


	
}
